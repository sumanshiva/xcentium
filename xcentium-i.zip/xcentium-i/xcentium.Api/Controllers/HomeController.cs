using HtmlAgilityPack;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using AngleSharp;
using AngleSharp.Parser.Html;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace xcentium.Api.Controllers
{
    [Route("api/[controller]")]
    public class HomeController : Controller
    {
        public HomeController() { }

        [HttpPost]
        [Route("scrape")]
        [EnableCors("AllowAllOrigins")]
        public ScrapedData GetDataAsync(string url)
        {
            var hasUrl = new Regex("^([a-z]+://|//)");
            var uri = string.Empty;
            if (!url.ToLower().StartsWith("http"))
            {
                uri = $"http://{url}";
            }
            Log.Information($"Url: {uri}");

            // var config = Configuration.Default.WithDefaultLoader();
            // var document = await BrowsingContext.New(config).OpenAsync(uri);
            // var cellSelector = "tr>td:nth-child(3)";
            // var allrows = "tr:not(:first-child)";
            // var allDivs = "body>div";

            // var images = document.QuerySelectorAll("*").Where(c => c.LocalName == "img");
            // var cells = document.QuerySelectorAll(cellSelector);
            // var rows = document.QuerySelectorAll(allrows);
            // var divs = document.QuerySelectorAll(allDivs);
            
            // var fileExtensions = new string[] { ".jpg", ".JPG", ".png", ".PNG" };
            // var result = from element in document.All
            //              from attribute in element.Attributes
            //              where fileExtensions.Any(e => attribute.Value.EndsWith(e))
            //              select attribute;

            List<Image> lstImage = new List<Image>();
            ScrapedData sd = new ScrapedData();
            var wordAndCount = new Dictionary<string, int>();
            HttpClient httpClient = null;
            using (httpClient = new HttpClient())
            {
                var loadedDocument = httpClient.GetStringAsync(uri).Result;
                var document = new HtmlDocument();
                document.LoadHtml(loadedDocument);

                var scrapedHtml = document.DocumentNode.Descendants().Where(x =>
                                x.NodeType == HtmlNodeType.Text &&
                                x.ParentNode.Name != "script" &&
                                x.ParentNode.Name != "style" &&
                                x.ParentNode.Name != "head")
                                .Aggregate(string.Empty, (current, node) => current + node.InnerText);

                // get all img's
                var imgSrc = (from img in document.DocumentNode.Descendants("img")
                              where img.Attributes["src"] != null
                              select new
                              {
                                  attr = img.Attributes["src"]
                              }).ToList();

                int i = 0;
                foreach (var item in imgSrc)
                {
                    var itemImg = new Image(){
                    Src = hasUrl.IsMatch(item.attr.Value)
                         ? item.attr.Value
                         : $"{uri}{item.attr.Value}",
                    Id = ++i
                    };
                    sd.Image.Add(itemImg);
                }

                wordAndCount = Helper.ExtractWords(scrapedHtml);
            }

            foreach(var word in wordAndCount)
            {
                var item = new Words(){
                    Word = word.Key.ToString(), Count = word.Value
                };
                sd.WordCount.Add(item);
            }
            //return new JsonResult(images.Select(x => x.OuterHtml).ToArray());
            return sd;
        }
    }
}