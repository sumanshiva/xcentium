
using System.Collections.Generic;

public class ScrapedData {
    public List<Image> Image { get; set; }
    public List<Words> WordCount { get; set; } 

    public ScrapedData() {
        this.Image = new List<Image>();
        this.WordCount = new List<Words>();
    }
}

public class Words {
    public string Word { get; set; }
    public int Count { get; set; }
}

public class Image {
    public string Src { get; set; }
    public int Id { get; set; }
}