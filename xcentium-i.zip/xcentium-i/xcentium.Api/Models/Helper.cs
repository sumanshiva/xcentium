

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using Serilog;

public static class Helper {

    public static Image ExtractImages(string url){
        Image image = new Image();
        using(HttpClient client = new HttpClient())
        {
            HttpResponseMessage message = client.GetAsync(url).Result;
            image.Src = message.Content.ReadAsStringAsync().Result;
        }
        return image;
    }

    internal static Dictionary<string, int> ExtractWords(string loadedDocument)
    {
        var wordDictionary = new Dictionary<string, int>();
        try
            {
                var wordsList = FormatString(loadedDocument);
                wordDictionary = (from word in wordsList
                                      group word by word into g
                                      select new
                                      {
                                          Word = g.Key,
                                          Count = g.Count()
                                      }).OrderByDescending(a => a.Count).Take(10).ToDictionary(a => a.Word, a => a.Count);
            }
            catch (Exception ex)
            {
               Log.Error($"Error occurred while extracting words. {ex.ToString()}");
            }
        return wordDictionary;
    }

    private static List<string> FormatString(string fmtString)
    {
        fmtString = Regex.Replace(fmtString, @"<[^>]+>|&nbsp;", "");
        var lstWords = new List<string>();
        var strBldr = new StringBuilder();

        //reads each character from the string
        foreach (var ch in fmtString)
        {
            //Check if the character is a letter
            if (Char.IsLetter(ch))
            {
                strBldr.Append(ch);
            }
            else
            {
                //If character is not a letter, add stringbuilder value to list and clear string builder.
                lstWords.Add(strBldr.ToString());
                strBldr.Clear();
            }

        }
        //exclude whitespaces and empty string 
        return lstWords.Where(s => !string.IsNullOrWhiteSpace(s)).Select(x => x.ToLower()).ToList();
    }
}