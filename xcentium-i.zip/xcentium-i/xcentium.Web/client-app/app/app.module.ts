import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';
import 'hammerjs';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PageNotFoundModule } from './page-not-found/page-not-found.module';
import { CoreModule } from './core/core.module';
import { SharedModule } from './shared/shared.module';
import { MaterialModule } from './shared/material.module';
import { environment } from '../environments/environment';
import { HomeModule } from './home/home.module';
import { ProgressSpinnerService } from './shared/progress-spinner/progress-spinner.service';
import { NgxCarouselModule } from 'ngx-carousel';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    FormsModule,
    PageNotFoundModule,
    AppRoutingModule,
    SharedModule,
    MaterialModule, // providers if any will be maintained singleton
    FlexLayoutModule,
    HomeModule,
    CoreModule.forRoot(),
    NgxCarouselModule
  ],
  providers: [
    [{provide: HTTP_INTERCEPTORS, useClass: ProgressSpinnerService, multi: true}]
  ],
  bootstrap: [AppComponent]
})
export class AppModule {

  constructor() {}
}
