import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import { ScrapedData } from '../models/ScrapedData';

@Injectable()
export class HomeService {
  public baseUrl = '';

  constructor(private http: HttpClient) {
    this.baseUrl = environment.API_BASE_URL + 'home';
  }

  getData = (url: string): Observable<any> => {
    const params = new HttpParams()
            .set('url', url);
    const body = [];
    const header = new HttpHeaders({
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            });
    
    return this.http.post(this.baseUrl + '/scrape', body, {params: params, headers: header})
        .map((data) => data)
        .catch(error => { return Observable.of({ description: error })})
  }
}