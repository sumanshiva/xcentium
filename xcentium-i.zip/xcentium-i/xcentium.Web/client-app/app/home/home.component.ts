import { Component, OnInit, OnDestroy, SecurityContext } from '@angular/core';
import { Subscription } from 'rxjs/Subscription';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HomeService } from './home.service';
import { Router, ActivatedRoute } from '@angular/router';
import { ScrapedData, Image } from './../models/ScrapedData';
import { DomSanitizer, SafeValue } from '@angular/platform-browser';
import { NgxCarousel } from 'ngx-carousel';

const urlRegex = '^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?';

@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit, OnDestroy {

  scraperData: Subscription;
  public scraperForm: FormGroup;
  public images = [];
  public words: any[];
  results: boolean = false;
  public carouselone: NgxCarousel;

  constructor(private fb: FormBuilder, private route: ActivatedRoute,
              private router: Router, private homeService: HomeService,
              private sanitizer: DomSanitizer) {
    this.scraperForm = fb.group({
      'url': [null, [Validators.required, Validators.pattern(urlRegex)]]
    });
  }

  ngOnInit() {
    this.carouselone = {
      grid: {xs: 1, sm: 1, md: 1, lg: 1, all: 0},
      slide: 1,
      speed: 400,
      interval: 4000,
      point: { visible: true },
      load: 2,
      touch: true,
      loop: true,
      custom: 'banner'
    };
  }

  scrapeData(form: any) {
    this.scraperData = this.homeService.getData(form.controls['url'].value)
      .subscribe(data => {
        this.results = true;
        debugger;
        this.images = data.image;
        this.words = data.wordCount;
        // let pic = new Image();
        // this.images.forEach(img => {
        //   pic.src = img.src;
        //   console.dir(pic.src);
        //   pic.id = img.id;
        // });
        //this.images.push(pic);
      });
  }

  ngOnDestroy() {
    this.scraperData.unsubscribe();
  }

  clear() {
    this.scraperForm.reset();
  }

  myfunc(e: Event) {
  }

  onmoveFn(e: Event){}

  next(e: Event) {
    debugger;
    const ctrl: any = document.getElementById('listItem');
    let currentImage = ctrl.value;
    let nextImage = ++currentImage;

    document.getElementById('listItem').setAttribute('data-slide-to', nextImage.toString());
    e.preventDefault();
  }

  convertByteStringToImage = (img: string): SafeValue => {
    return this.sanitizer.sanitize(SecurityContext.URL, 'data:image/jpeg;base64,' + img);
  }
}
