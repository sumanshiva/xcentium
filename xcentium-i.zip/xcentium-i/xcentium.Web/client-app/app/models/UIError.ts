export class UIError {
    public Description: string;

    constructor(description: string) {
        this.Description = description;
    }
}
