export const environment = {
  production: false,
  API_BASE_URL: 'http://localhost:5000/',
  IDENTITY_SERVER: 'http://localhost:5555'
};
